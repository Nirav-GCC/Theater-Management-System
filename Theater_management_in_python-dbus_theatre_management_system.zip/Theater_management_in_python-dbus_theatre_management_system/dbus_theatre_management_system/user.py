from admin import book_seats, cancel_seats, json_write_data, list_cities, list_movies, list_theatres
from termcolor import colored

def main_user():
    while True:
        try:
            user_choice = int(input(
                "\n 0.Exit\n 1.List City\n 2.List Theatre\n 3.List Movies\n 4.Book Ticket\n 5.Cancel Ticket\n *Select Option :"))
        except:
            print(colored("Only Numeric Values allowed...!",'red'))
            exit(1)
        if user_choice == 0:
            json_write_data()
            return
        elif user_choice == 1:
            list_cities()
        elif user_choice == 2:
            list_theatres()
        elif user_choice == 3:
            list_movies()
        elif user_choice == 4:
            book_seats()
        elif user_choice == 5:
            cancel_seats()
        else:
            print(colored("Wrong input select valid option"))
