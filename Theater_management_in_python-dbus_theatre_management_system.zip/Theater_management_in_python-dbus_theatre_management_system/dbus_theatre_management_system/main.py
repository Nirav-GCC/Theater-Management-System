
from admin import json_load_data, json_write_data, main_method
import os
from termcolor import colored

from user import main_user

if os.path.exists('TMS_DATA.json'):
    json_load_data()
else:
    json_write_data()

def mainpy():
    while True:
        try:
            user_management = int(
                input("\n 0.Exit\n 1.Admin\n 2.User\n *Select the option :"))
        except(KeyError, ValueError):
            print(colored("Only Numeric Values allowed...!",'red'))
            mainpy()
            break
        if user_management == 1:
            main_method()
        elif user_management == 2:
            main_user()
        elif user_management == 0:
            exit(1)
        else:
            print(colored("Please select valid option..!"))

mainpy()