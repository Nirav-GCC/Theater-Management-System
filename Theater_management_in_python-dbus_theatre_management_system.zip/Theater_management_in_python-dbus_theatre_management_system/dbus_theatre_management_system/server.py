#!/usr/bin/env python3
import dbus
from gi.repository import GLib
import dbus.service
import json
import dbus.mainloop.glib
from termcolor import colored
TMS = {}


def print_list(dict):
    dict_loop = 1
    for x in dict:
        print(dict_loop, x)
        dict_loop = dict_loop + 1


class DBusService_XML(dbus.service.Object):
    @dbus.service.method("org.example.demo.test",
                         in_signature='s', out_signature='')
    def add_city(self, city):  # Add city
        print(city)
        TMS[str(city)] = {}
        print(TMS)
        return

    @dbus.service.method("org.example.demo.test",
                         in_signature='', out_signature='s')
    def list_city(self):  # List city
        result_tms = str(TMS)

        return result_tms

    @dbus.service.method("org.example.demo.test",
                         in_signature='', out_signature='')
    def write_data(self):  # write data
        json_object = json.dumps(TMS, indent=4)

        with open("TMS_DATA.json", "w") as outfile:
            outfile.write(json_object)

    @dbus.service.method("org.example.demo.test",
                         in_signature='', out_signature='')
    def load_data(self):  # Load data
        with open("TMS_DATA.json") as test:
            data = test.read()

        load_file_data = json.loads(data)
        global TMS
        TMS = load_file_data

    @dbus.service.method("org.example.demo.test",
                         in_signature='', out_signature='')
    def rename_city(self, new_city_name, city_number):
        print("In server", city_number, ":", new_city_name)
        cityloop = 1
        for key in list(TMS):
            if city_number == cityloop:
                if new_city_name in TMS:
                    print("City is already exist...!")
                else:
                    old_city = key
                    TMS[str(new_city_name)] = TMS[old_city]
                    del TMS[old_city]
                    return
            else:
                print("City number not matched..!")
            cityloop = cityloop+1
        return

    @dbus.service.method("org.example.demo.test",
                         in_signature='', out_signature='')
    def delete_city(self, city_number):
        cityloop = 1
        for key in list(TMS):
            if city_number == cityloop:
                del TMS[key]
                return
            else:
                print("Wrong City number added..!")
            cityloop = cityloop + 1
        return

    @dbus.service.method("org.example.demo.test",
                         in_signature='', out_signature='')
    def add_theatre(self, city_number, th_name):
        cityloop = 1
        for key in TMS:
            if city_number == cityloop:
                TMS[key][str(th_name)] = {}
            cityloop = cityloop + 1
        return

    @dbus.service.method("org.example.demo.test",
                         in_signature='', out_signature='s')
    def list_theatre(self, city_number):
        cityloop = 1
        for key in list(TMS):
            if city_number == cityloop:
                return_theatres = str(TMS[key])
                return return_theatres
            cityloop = cityloop + 1
        return

    @dbus.service.method("org.example.demo.test",
                         in_signature='sss', out_signature='')
    def rename_theatre(self, th_name, new_th_name, city_name):

        if city_name in list(TMS):
            if th_name in list(TMS[city_name]):
                TMS[city_name][new_th_name] = TMS[city_name][th_name]
                del TMS[city_name][th_name]

    @dbus.service.method("org.example.demo.test",
                         in_signature='', out_signature='s')
    def return_tmsdata(self):
        result_tms = str(TMS)
        return result_tms

    @dbus.service.method("org.example.demo.test",
                         in_signature='ss', out_signature='')
    def delete_theatre(self, th_name, city_name):
        if city_name in TMS:
            if th_name in TMS[city_name]:
                del TMS[city_name][th_name]

    @dbus.service.method("org.example.demo.test",
                         in_signature='sss', out_signature='')
    def add_movie(self, city_name, th_name, movie_name):
        if city_name in TMS:
            if th_name in TMS[city_name]:
                TMS[city_name][th_name][str(movie_name)] = {}

    @dbus.service.method("org.example.demo.test",
                         in_signature='ssss', out_signature='')
    def rename_movie(self, city_name, th_name, new_movie_name, old_movie):
        if city_name in TMS:
            if th_name in TMS[city_name]:
                if old_movie in TMS[city_name][th_name]:
                    TMS[city_name][th_name][new_movie_name] = TMS[city_name][th_name][old_movie]
                    del TMS[city_name][th_name][old_movie]

    @dbus.service.method("org.example.demo.test",
                         in_signature='sss', out_signature='')
    def delete_movie(self, city_name, th_name, movie_name):
        if city_name in TMS:
            if th_name in TMS[city_name]:
                if movie_name in TMS[city_name][th_name]:
                    del TMS[city_name][th_name][movie_name]

    @dbus.service.method("org.example.demo.test",
                         in_signature='ss', out_signature='s')
    def list_movie(self, city_name, th_name):
        if city_name in TMS:
            if th_name in TMS[city_name]:
                list_mov = str(TMS[city_name][th_name])
                return list_mov
        return

    @dbus.service.method("org.example.demo.test",
                         in_signature='sssssii', out_signature='')
    def add_show(self, city_name, th_name, movie_name, mov_date, mov_time, seat_fee, seat_size):
        print(seat_size)
        if city_name in TMS:
            if th_name in TMS[city_name]:
                if movie_name in TMS[city_name][th_name]:
                    TMS[city_name][th_name][movie_name][str(mov_date)] = {}
                    if mov_date in TMS[city_name][th_name][movie_name]:
                        TMS[city_name][th_name][movie_name][mov_date][str(mov_time)] = {
                        }
                        if mov_time in TMS[city_name][th_name][movie_name][mov_date]:
                            TMS[city_name][th_name][movie_name][mov_date][mov_time][seat_fee] = {
                            }
                            if seat_fee in TMS[city_name][th_name][movie_name][mov_date][mov_time]:

                                for iloop in range(1, seat_size+1):
                                    TMS[city_name][th_name][movie_name][mov_date][mov_time][seat_fee][iloop] = [
                                        "Avilable"]

    @dbus.service.method("org.example.demo.test",
                         in_signature='sssssii', out_signature='')
    def book_seat(self, city_name, th_name, movie_name, mov_date, mov_time, mov_fee, selected_seat):
        if city_name in TMS:
            if th_name in TMS[city_name]:
                if movie_name in TMS[city_name][th_name]:
                    if mov_date in TMS[city_name][th_name][movie_name]:
                        if mov_time in TMS[city_name][th_name][movie_name][mov_date]:
                            if mov_fee in TMS[city_name][th_name][movie_name][mov_date][mov_time]:
                                if selected_seat in TMS[city_name][th_name][movie_name][mov_date][mov_time][mov_fee]:
                                    if TMS[city_name][th_name][movie_name][mov_date][mov_time][mov_fee][selected_seat] == ["Avilable"]:
                                        TMS[city_name][th_name][movie_name][mov_date][mov_time][mov_fee][selected_seat] = ["Booked"]
                                        


    @dbus.service.method("org.example.demo.test",
                         in_signature='sssssii', out_signature='')
    def cancel_seat(self, city_name, th_name, movie_name, mov_date, mov_time, mov_fee, selected_seat):
        if city_name in TMS:
            if th_name in TMS[city_name]:
                if movie_name in TMS[city_name][th_name]:
                    if mov_date in TMS[city_name][th_name][movie_name]:
                        if mov_time in TMS[city_name][th_name][movie_name][mov_date]:
                            if mov_fee in TMS[city_name][th_name][movie_name][mov_date][mov_time]:
                                if selected_seat in TMS[city_name][th_name][movie_name][mov_date][mov_time][mov_fee]:
                                    if TMS[city_name][th_name][movie_name][mov_date][mov_time][mov_fee][selected_seat] == ["Booked"]:
                                        TMS[city_name][th_name][movie_name][mov_date][mov_time][mov_fee][selected_seat] = ["Avilable"]
                                        




if __name__ == "__main__":
    print("Starting TMS Server ...")
    print(colored("TMS Server is online.",'green'))
    dbus.mainloop.glib.DBusGMainLoop(set_as_default=True)
    bus = dbus.SessionBus()
    loop = GLib.MainLoop()
    name = dbus.service.BusName("org.example.demo.test", bus)
    object = DBusService_XML(bus, "/org/example/demo/test")
    loop.run()
