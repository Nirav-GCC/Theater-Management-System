import dbus
from gi.repository import GLib
import os
import dbus.service
import signal
import ast
from termcolor import colored

bus = dbus.SessionBus()
BUS = "org.example.demo.test"
server_object = bus.get_object(BUS, "/org/example/demo/test")
loop = GLib.MainLoop()
INTERVAL = 2


def user_book_seat(msg, dict):
    dict_loop = 1
    temp_dict = {}

    for x in dict:
        if dict[x] == ["Avilable"]:
            print(f"press {dict_loop} to book seat No:{x}")
            temp_dict[dict_loop] = x
            dict_loop = dict_loop + 1
    choice = int(input(msg))
    return temp_dict[choice]


def user_cancel_seat(msg, dict):
    dict_loop = 1
    temp_dict = {}

    for x in dict:
        if dict[x] == ["Booked"]:
            print(f"press {dict_loop} to cancel booked seat No:{x}")
            temp_dict[dict_loop] = x
            dict_loop = dict_loop + 1
    choice = int(input(msg))
    return temp_dict[choice]


def user_input(msg, dict):
    dict_loop = 1
    temp_dict = {}

    for x in dict:
        print(dict_loop, x)
        temp_dict[dict_loop] = x
        dict_loop = dict_loop + 1
    choice = int(input(msg))
    return temp_dict[choice]


def tms_data():
    reply = server_object.return_tmsdata()
    tms = ast.literal_eval(reply)
    city_name = user_input("select city number :", tms)
    print(city_name)
    return True


def print_list(dict):
    dict_loop = 1
    for x in dict:
        print(dict_loop, x)
        dict_loop = dict_loop + 1


def add_cities():
    reply = server_object.return_tmsdata()
    tms = ast.literal_eval(reply)
    city_name = input("Enter the city name :").upper()
    if city_name in tms:
        print(colored("ERROR : city is already present...!", 'red'))
        add_cities()
        return
    reply = server_object.add_city(city_name)
    
    return True
    


def list_cities():
    reply = server_object.return_tmsdata()
    tms = ast.literal_eval(reply)
    if len(tms) == 0:
        print(colored("Theare are no cities to list..!", 'red'))
        return
    reply = server_object.list_city()
    city_list = ast.literal_eval(reply)
    print_list(city_list)
    return True
    


def rename_cities():
    reply = server_object.return_tmsdata()
    tms = ast.literal_eval(reply)
    if len(tms) == 0:
        print(colored("There is no cities to rename..!",'red'))
        
        return
    else:
        print_list(tms)
    while True:
        try:
            city_number = int(input("Select the city number to change :"))
            if city_number > len(tms):
                print(colored("Please select city from avilable list.",'red'))
                rename_cities()
                break
        except (ValueError, KeyError):
            print(colored("Invalid Input..!", 'red'))
            rename_cities()
            break
        new_city_name = input("Enter the new city name :").upper()
        if new_city_name in tms:
            print(colored("Error : City is already present..!"))
            rename_cities()
            return
        reply = server_object.rename_city(new_city_name, city_number)
        
        return True


def delete_cities():
    reply = server_object.return_tmsdata()
    tms = ast.literal_eval(reply)
    if len(tms) == 0:
        print(colored("There is no cities to delete..!",'red'))
        return
    else:
        print_list(tms)
    while True:
        try:
            city_number = int(input("Select the city number to delete :"))
            if city_number > len(tms):
                print(colored("Please select city from avilable list.",'red'))
                delete_cities()
                break
        except(ValueError,KeyError):
            print(colored("Invalid Input..!", 'red'))
            delete_cities()
            break

        reply = server_object.delete_city(city_number)
        print(colored("City delete from list.",'green'))
        
        return True




def add_theatres():
    reply = server_object.return_tmsdata()
    tms = ast.literal_eval(reply)
    if len(tms) == 0:
        print(colored("There is no cities to delete..!",'red'))
        return
    else:
        print_list(tms)
    while True:
        try:
            city_number = int(input("Select the city number :"))
            if city_number > len(tms):
                print(colored("Please select city from avilable list.",'red'))
                add_theatres()
                break
        except(ValueError,KeyError):
            print(colored("Invalid Input..!", 'red'))
            add_theatres()
            break
        th_name = input("Enter the theatre name :").upper()
        reply = server_object.add_theatre(city_number, th_name)
        
        return True


def list_theatres():
    reply = server_object.return_tmsdata()
    tms = ast.literal_eval(reply)
    if len(tms) == 0:
        print(colored("There is no cities in list..!",'red'))
        return
    else:
        print_list(tms)
    while True:
        try:
            city_number = int(input("Select the city number to list theatres :"))
            if city_number > len(tms):
                print(colored("Please select city from avilable list.",'red'))
                list_theatres()
                break
        except(ValueError,KeyError):
            print(colored("Invalid Input..!", 'red'))
            list_theatres()
            break
        reply = server_object.list_theatre(city_number)
        th_list = ast.literal_eval(reply)
        print_list(th_list)
        
        return True


def rename_theatres():
    reply = server_object.return_tmsdata()
    tms = ast.literal_eval(reply)
    if len(tms) == 0:
        print(colored("There is no cities to delete..!",'red'))
        return
    while True:
        try:
            city_name = user_input("select city number :", tms)
            if  city_name not in tms:
                print(colored("Please select city from avilable list.",'red'))
                rename_theatres()
                break
        except(ValueError,KeyError):
            print(colored("Invalid Input..!", 'red'))
            rename_theatres()
            break
        if len(tms[city_name]) == 0:
            print(colored("There is no theatre to rename..!",'red'))
            return
        try:
            th_name = user_input("Select Theatre name :", tms[city_name])
            if th_name not in tms[city_name]:
                print(colored("Please select city from avilable list.",'red'))
                rename_theatres()
                break
        except(ValueError,KeyError):
            print(colored("Invalid Input..!", 'red'))
            rename_theatres()
            break
        new_th_name = input("Enter the theatre name :").upper()
        reply = server_object.rename_theatre(th_name, new_th_name, city_name)
        
        return True






def delete_theatres():
    reply = server_object.return_tmsdata()
    tms = ast.literal_eval(reply)
    if len(tms) == 0:
        print(colored("There is no cities to delete..!",'red'))
        return
    while True:
        try:
            city_name = user_input("select city number :", tms)
            if  city_name not in tms:
                print(colored("Please select city from avilable list.",'red'))
                delete_theatres()
                break
        except(ValueError,KeyError):
            print(colored("Invalid Input..!", 'red'))
            delete_theatres()
            break
        if len(tms[city_name]) == 0:
            print(colored("There is no theatre to rename..!",'red'))
            return
        try:
            th_name = user_input("Select Theatre name :", tms[city_name])
            if th_name not in tms[city_name]:
                print(colored("Please select city from avilable list.",'red'))
                delete_theatres()
                break
        except(ValueError,KeyError):
            print(colored("Invalid Input..!", 'red'))
            delete_theatres()
            break
        reply = server_object.delete_theatre(th_name, city_name)
        print(colored("Theatre deleted from list.",'green'))
        
        return True



def add_movies():
    reply = server_object.return_tmsdata()
    tms = ast.literal_eval(reply)
    if len(tms) == 0:
        print(colored("There is no cities to delete..!",'red'))
        return
    while True:
        try:
            city_name = user_input("select city number :", tms)
            if  city_name not in tms:
                print(colored("Please select city from avilable list.",'red'))
                add_movies()
                break
        except(ValueError,KeyError):
            print(colored("Invalid Input..!", 'red'))
            add_movies()
            break
        if len(tms[city_name]) == 0:
            print(colored("There is no theatre to add movie..!",'red'))
            return
        try:
            th_name = user_input("Select Theatre name :", tms[city_name])
            if th_name not in tms[city_name]:
                print(colored("Please select city from avilable list.",'red'))
                add_movies()
                break
        except(ValueError,KeyError):
            print(colored("Invalid Input..!", 'red'))
            add_movies()
            break
        movie_name = input("Enter the movie name :").upper()
        reply = server_object.add_movie(city_name, th_name, movie_name)
        
        return True



def list_movies():
    reply = server_object.return_tmsdata()
    tms = ast.literal_eval(reply)
    if len(tms) == 0:
        print(colored("There is no cities in list..!",'red'))
        return
    while True:
        try:
            city_name = user_input("select city number :", tms)
            if  city_name not in tms:
                print(colored("Please select city from avilable list.",'red'))
                list_movies()
                break
        except(ValueError,KeyError):
            print(colored("Invalid Input..!", 'red'))
            list_movies()
            break
        if len(tms[city_name]) == 0:
            print(colored("There is no theatre to list movie..!",'red'))
            return
        try:
            th_name = user_input("Select Theatre name :", tms[city_name])
            if th_name not in tms[city_name]:
                print(colored("Please select city from avilable list.",'red'))
                list_movies()
                break
        except(ValueError,KeyError):
            print(colored("Invalid Input..!", 'red'))
            list_movies()
            break
        reply = server_object.list_movie(city_name, th_name)
        mlist = ast.literal_eval(reply)
        print_list(mlist)
        
        return True


def rename_movies():
    reply = server_object.return_tmsdata()
    tms = ast.literal_eval(reply)
    if len(tms) == 0:
        print(colored("There is no cities to delete..!",'red'))
        return
    while True:
        try:
            city_name = user_input("select city number :", tms)
            if  city_name not in tms:
                print(colored("Please select city from avilable list.",'red'))
                rename_movies()
                break
        except(ValueError,KeyError):
            print(colored("Invalid Input..!", 'red'))
            rename_movies()
            break
        if len(tms[city_name]) == 0:
            print(colored("There is no theatre to list movie..!",'red'))
            return
        try:
            th_name = user_input("Select Theatre name :", tms[city_name])
            if th_name not in tms[city_name]:
                print(colored("Please select theatre from avilable list.",'red'))
                list_movies()
                break
        except(ValueError,KeyError):
            print(colored("Invalid Input..!", 'red'))
            rename_movies()
            break
        try:
            old_movie = user_input("Select the movie to rename :",
                                tms[city_name][th_name])
            if old_movie not in tms[city_name][th_name]:
                print(colored("Please select movie from avilable list.",'red'))
                rename_movies()
                break
        except(ValueError,KeyError):
            print(colored("Invalid Input..!", 'red'))
            rename_movies()
            break
        new_movie_name = input("Enter new movie name :").upper()
        if new_movie_name in tms[city_name][th_name]:
            print(colored("Error : Movie is already in list",'red'))
            rename_movies()
            break
        reply = server_object.rename_movie(
            city_name, th_name, new_movie_name, old_movie)
        
        return True


def delete_movies():
    reply = server_object.return_tmsdata()
    tms = ast.literal_eval(reply)
    if len(tms) == 0:
        print(colored("There is no cities to delete..!",'red'))
        return
    while True:
        try:
            city_name = user_input("select city number :", tms)
            if  city_name not in tms:
                print(colored("Please select city from avilable list.",'red'))
                delete_movies()
                break
        except(ValueError,KeyError):
            print(colored("Invalid Input..!", 'red'))
            delete_movies()
            break
        try:
            th_name = user_input("Select Theatre name :", tms[city_name])
            if th_name not in tms[city_name]:
                print(colored("Please select theatre from avilable list.",'red'))
                delete_movies()
                break
        except(ValueError,KeyError):
            print(colored("Invalid Input..!", 'red'))
            delete_movies()
            break
        try:
            movie_name = user_input(
                "Select the movie to rename :", tms[city_name][th_name])
            if movie_name not in tms[city_name][th_name]:
                print(colored("Please select movie from avilable list.",'red'))
                delete_movies()
                break
        except(ValueError,KeyError):
            print(colored("Invalid Input..!", 'red'))
            delete_movies()
            break
        reply = server_object.delete_movie(city_name, th_name, movie_name)
        print(colored("Movie is deleted",'green'))
        
        return True
            


def add_shows():
    reply = server_object.return_tmsdata()
    tms = ast.literal_eval(reply)
    if len(tms) == 0:
        print(colored("There is no cities to add shows..!",'red'))
        return
    while True:
        try:
            city_name = user_input("select city number :", tms)
            if  city_name not in tms:
                print(colored("Please select city from avilable list.",'red'))
                add_shows()
                break
        except(ValueError,KeyError):
            print(colored("Invalid Input..!", 'red'))
            add_shows()
            break
        try:
            th_name = user_input("Select Theatre name :", tms[city_name])
            if th_name not in tms[city_name]:
                print(colored("Please select theatre from avilable list.",'red'))
                add_shows()
                break
        except(ValueError,KeyError):
            print(colored("Invalid Input..!", 'red'))
            add_shows()
            break
        try:
            if len(tms[city_name][th_name]) == 0:
                print(colored("There is no movies Found..!",'red'))
                return
            movie_name = user_input(
                "Select the movie :", tms[city_name][th_name])
            if movie_name not in tms[city_name][th_name]:
                print(colored("Please select movie from avilable list.",'red'))
                add_shows()
                break
        except(ValueError,KeyError):
            print(colored("Invalid Input..!", 'red'))
            add_shows()
            break
        print(colored('Add date in this formate DD/MM/YYYY = 26/01/2022 ', 'red'))
        mov_date = input("Enter the movie date :")
        print(colored('Add Time in this format HH:MM AM/PM', 'red'))
        mov_time = input("Enter the movie time :")
        seat_fee = int(input("Enter the seat price :"))
        seat_size = int(input("allocate total seat for this movie :"))
        reply = server_object.add_show(
            city_name, th_name, movie_name, mov_date, mov_time, seat_fee, seat_size)
        
        return True


def book_seats():
    reply = server_object.return_tmsdata()
    tms = ast.literal_eval(reply)
    if len(tms) == 0:
        print(colored("There is no cities in list to book seats..!",'red'))
        return
    while True:
        try:
            city_name = user_input("select city number :", tms)
            if  city_name not in tms:
                print(colored("Please select city from avilable list.",'red'))
                book_seats()
                break
        except(ValueError,KeyError):
            print(colored("Invalid Input..!", 'red'))
            book_seats()
            break
        if len(tms[city_name]) == 0:
            print(colored("There is no theatre to book..!",'red'))
            return
        try:
            th_name = user_input("Select Theatre number :", tms[city_name])
            if th_name not in tms[city_name]:
                print(colored("Please select theatre from avilable list.",'red'))
                book_seats()
                break
        except(ValueError,KeyError):
            print(colored("Invalid Input..!", 'red'))
            book_seats()
            break
        try:
            movie_name = user_input(
                "Select the movie :", tms[city_name][th_name])
            if movie_name not in tms[city_name][th_name]:
                print(colored("Please select movie from avilable list.",'red'))
                book_seats()
                break
        except(ValueError,KeyError):
            print(colored("Invalid Input..!", 'red'))
            book_seats()
            break
        if len(tms[city_name][th_name][movie_name]) == 0:
            print(colored("There is no date found for this movie check after some time..!",'red'))
            return
        try:
            mov_date = user_input("Select the date :",
                                tms[city_name][th_name][movie_name])
            if mov_date not in tms[city_name][th_name][movie_name]:
                print(colored("Please select movie date from avilable list.",'red'))
                book_seats()
                break
        except(ValueError,KeyError):
            print(colored("Invalid Input..!", 'red'))
            book_seats()
            break
        if len(tms[city_name][th_name][movie_name][mov_date]) == 0:
            print(colored("There is no time found for this movie check after some time..!",'red'))
            return
        try:
            mov_time = user_input("Select the movie time :",
                                tms[city_name][th_name][movie_name][mov_date])
            if mov_time not in tms[city_name][th_name][movie_name][mov_date]:
                print(colored("Please select movie time from avilable list.",'red'))
                book_seats()
                break
        except(ValueError,KeyError):
            print(colored("Invalid Input..!", 'red'))
            book_seats()
            break
        if len(tms[city_name][th_name][movie_name][mov_date][mov_time]) == 0:
            print(colored("There is no fees found for this movie check after some time..!",'red'))
            return
        try:
            mov_fee = user_input("Press 1 to continue for ticket booking :",
                                tms[city_name][th_name][movie_name][mov_date][mov_time])
            if mov_fee not in tms[city_name][th_name][movie_name][mov_date][mov_time]:
                print(colored("Just press 1 to continue there is no movie fees are fixed.",'red'))
                book_seats()
                break
        except(ValueError,KeyError):
            print(colored("Just press 1 to continue there is no option to select movie fees, price are fixed.", 'red'))
            book_seats()
            break
        if len(tms[city_name][th_name][movie_name][mov_date][mov_time][mov_fee]) == 0:
            print(colored("There are no seats allocated for this movie check after some time..!",'red'))
            return
        selected_seat = user_book_seat(
            "Enter seat No :", tms[city_name][th_name][movie_name][mov_date][mov_time][mov_fee])
        reply = server_object.book_seat(
            city_name, th_name, movie_name, mov_date, mov_time, mov_fee, selected_seat)
        
        return True


def cancel_seats():
    reply = server_object.return_tmsdata()
    tms = ast.literal_eval(reply)
    if len(tms) == 0:
        print(colored("There is no cities in list to cancel seat..!",'red'))
        return
    while True:
        try:
            city_name = user_input("select city number :", tms)
            if  city_name not in tms:
                print(colored("Please select city from avilable list.",'red'))
                book_seats()
                break
        except(ValueError,KeyError):
            print(colored("Invalid Input..!", 'red'))
            book_seats()
            break
        if len(tms[city_name]) == 0:
            print(colored("There is no theatre to book..!",'red'))
            return
        try:
            th_name = user_input("Select Theatre number :", tms[city_name])
            if th_name not in tms[city_name]:
                print(colored("Please select theatre from avilable list.",'red'))
                book_seats()
                break
        except(ValueError,KeyError):
            print(colored("Invalid Input..!", 'red'))
            book_seats()
            break
        try:
            movie_name = user_input(
                "Select the movie :", tms[city_name][th_name])
            if movie_name not in tms[city_name][th_name]:
                print(colored("Please select movie from avilable list.",'red'))
                book_seats()
                break
        except(ValueError,KeyError):
            print(colored("Invalid Input..!", 'red'))
            book_seats()
            break
        if len(tms[city_name][th_name][movie_name]) == 0:
            print(colored("There is no date found for this movie check after some time..!",'red'))
            return
        try:
            mov_date = user_input("Select the date :",
                                tms[city_name][th_name][movie_name])
            if mov_date not in tms[city_name][th_name][movie_name]:
                print(colored("Please select movie date from avilable list.",'red'))
                book_seats()
                break
        except(ValueError,KeyError):
            print(colored("Invalid Input..!", 'red'))
            book_seats()
            break
        if len(tms[city_name][th_name][movie_name][mov_date]) == 0:
            print(colored("There is no time found for this movie check after some time..!",'red'))
            return
        try:
            mov_time = user_input("Select the movie time :",
                                tms[city_name][th_name][movie_name][mov_date])
            if mov_time not in tms[city_name][th_name][movie_name][mov_date]:
                print(colored("Please select movie time from avilable list.",'red'))
                book_seats()
                break
        except(ValueError,KeyError):
            print(colored("Invalid Input..!", 'red'))
            book_seats()
            break
        if len(tms[city_name][th_name][movie_name][mov_date][mov_time]) == 0:
            print(colored("There is no fees found for this movie check after some time..!",'red'))
            return
        try:
            mov_fee = user_input("Press 1 to continue for ticket booking :",
                                tms[city_name][th_name][movie_name][mov_date][mov_time])
            if mov_fee not in tms[city_name][th_name][movie_name][mov_date][mov_time]:
                print(colored("Just press 1 to continue cancellation process there is no movie fees are fixed.",'red'))
                book_seats()
                break
        except(ValueError,KeyError):
            print(colored("Just press 1 to continue there is no option to select movie fees, price are fixed.", 'red'))
            book_seats()
            break
        if len(tms[city_name][th_name][movie_name][mov_date][mov_time][mov_fee]) == 0:
            print(colored("There are no seats allocated for this movie check after some time..!",'red'))
            return
        selected_seat = user_cancel_seat(
            "Enter seat No :", tms[city_name][th_name][movie_name][mov_date][mov_time][mov_fee])
        reply = server_object.cancel_seat(
            city_name, th_name, movie_name, mov_date, mov_time, mov_fee, selected_seat)
        
        return True


def json_write_data():
    print()
    print("Writing the data in file")
    reply = server_object.write_data()
    return True


def json_load_data():
    reply = server_object.load_data()
    return True


if os.path.exists('TMS_DATA.json'):
    json_load_data()
else:
    json_write_data()


def main_method():
    while True:
        try:
            choice = int(
                input("\n 1)Add City\n 2)List City\n 3)Rename City\n 4)Delete Cities\n 5)Add Theatre\n 6)List Theatres\n 7)Rename Theatres\n 8)Delete Theatre\n 9)Add Movie\n 10)Rename Movies\n 11)List Movies\n 12)Delete Movies\n 13)Add Show\n 14) Book Seat\n 15)Cancel Seat\n 16)Exit to main menu\n  Select options :"))
        except(ValueError, KeyError):
            print(colored("Only numeric values valid.",'red'))
            main_method()
            break
        if choice == 1:
            add_cities()
        elif choice == 2:
            list_cities()
        elif choice == 3:
            rename_cities()
        elif choice == 4:
            delete_cities()
        elif choice == 5:
            add_theatres()
        elif choice == 6:
            list_theatres()
        elif choice == 7:
            rename_theatres()
        elif choice == 8:
            delete_theatres()
        elif choice == 9:
            add_movies()
        elif choice == 10:
            rename_movies()
        elif choice == 11:
            list_movies()
        elif choice == 12:
            delete_movies()
        elif choice == 13:
            add_shows()
        elif choice == 14:
            book_seats()
        elif choice == 15:
            cancel_seats()
        elif choice == 16:
            json_write_data()
            break
        else:
            print(colored("Avilable Choicees are to 1 to 15 only...!", 'red'))
            main_method()
        # return True


def handler(signum, frame):
    json_write_data()
    print()
    exit(1)


signal.signal(signal.SIGTSTP, handler)
signal.signal(signal.SIGINT, handler)

if __name__ == "__main__":
    print("Starting Client Demo 1...")
    GLib.timeout_add_seconds(interval=INTERVAL,
                             function=main_method)
    loop.run()




