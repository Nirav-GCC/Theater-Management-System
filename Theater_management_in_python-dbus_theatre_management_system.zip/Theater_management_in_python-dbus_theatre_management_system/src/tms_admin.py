import json
from termcolor import colored
import signal
TMS = {}


def tms_admin():
    # add cities, add movies, add theatre
    while True:
        admin_choice = int(
            input("\n 0.Exit to admin menu\n 1.Add cities\n 2.Rename City\n 3.List Cities\n 4.Delete city\n 5.Add Theatres\n 6.List Theatres\n 7.Rename Theatres\n 8.Delete Theatre\n 9.Add Movies\n 10.List Movies\n 11.Rename Movies\n 12.Delete Movies\n 13.Add Show\n*select The Option :"))
        if admin_choice == 0:
            write_data()
            return
        elif admin_choice == 1:
            add_cities()
        elif admin_choice == 2:
            rename_city()
        elif admin_choice == 3:
            list_cities()
        elif admin_choice == 4:
            delete_city()
        elif admin_choice == 5:
            add_theatres()
        elif admin_choice == 6:
            list_theatre()
        elif admin_choice == 7:
            rename_theatre()
        elif admin_choice == 8:
            delete_theatre()
        elif admin_choice == 9:
            add_movies()
        elif admin_choice == 10:
            list_movies()
        elif admin_choice == 11:
            rename_movies()
        elif admin_choice == 12:
            delete_movies()
        elif admin_choice == 13:
            add_show()
        else:
            print("Wrong Choice..!")


def user_input(msg, dict):
    dict_loop = 1
    temp_dict = {}

    for x in dict:
        print(dict_loop, x)
        temp_dict[dict_loop] = x
        dict_loop = dict_loop + 1
    choice = int(input(msg))
    return temp_dict[choice]


def add_cities():
    try:
        total_add_cities = int(
            input("\nEnter total add cities you want to add :"))
    except (KeyError, ValueError):
        print("Only Numeric Value Valid..!")
        add_cities()
        return
    city_loop = 0
    for city_loop in range(total_add_cities):
        city_name = input("Enter the name of city :").upper()
        if city_name in TMS:
            print("ERROR : city alredy exist..!")
            add_cities()
            return
        else:
            TMS[city_name] = {}
        city_loop = city_loop + 1


def rename_city():
    if not TMS:
        print("No city Found please enter city first")
        return
    else:
        list_cities()

        try:
            city_num = int(input("select the city number to change :"))
        except (KeyError, ValueError):
            print("Only Numeric Value Valid..!")
            rename_city()
            return
        cityloop = 1
        for key in list(TMS):
            if city_num == cityloop:
                new_city = input("Enter new city name :").upper()
                if new_city in TMS:
                    print("City is already exist...!")
                else:
                    old_city = key
                    TMS[new_city] = TMS[old_city]
                    del TMS[old_city]
                    else_flag = True
                    rename_city()
                    return
            else:
                print("City number not matched..!")
            cityloop = cityloop+1


def delete_city():
    else_flag = False
    if not TMS:
        print()
        print("No city found to delete..!")
    else:
        list_cities()
        while True:
            try:
                city_num = int(input("Select city to number to delete  :"))
            except:
                print("Only Numberic value allowed..!")
                delete_city()
                return
            cityloop = 1
            for key in list(TMS):
                if city_num == cityloop:
                    citydelete = key
                    del TMS[citydelete]
                    else_flag = True
                    return
                cityloop = cityloop + 1
            if else_flag == False:
                print("Wrong Number Selected.")


def list_cities():
    if not TMS:
        print("No city to list first enter some city first ..!")
    else:

        cityloop = 1
        cities = {}
        for key in TMS:
            print(cityloop, key)
            cities[cityloop] = key
            cityloop = cityloop + 1
        return cities


def write_data():
    json_object = json.dumps(TMS, indent=4)

    with open("TMS_DATA.json", "w") as outfile:
        outfile.write(json_object)


def load_data():

    with open("TMS_DATA.json") as test:
        data = test.read()

    load_file_data = json.loads(data)
    global TMS
    TMS = load_file_data


def add_theatres():
    if not TMS:
        print("City not found to add theatre..!")
    else:
        else_flag = False
        cities = list_cities()
        while True:
            try:
                city_num = int(input("Enter the city number to add theatre :"))
            except:
                print("Only Numeric value allowed..!")
                add_theatres()
                return
            if city_num in cities:
                city_name = cities[city_num]
                th_name = input("Enter the theatre name :").upper()
                if th_name in TMS[city_name]:
                    print("Theatre is Alreay Exist..!")
                    add_theatres()
                    return
                else:
                    TMS[city_name][th_name] = {}
                    else_flag = True
                    return
            if else_flag == False:
                print("Invalid inout ..Enter again")


def rename_theatre():
    if not TMS:
        print("City not found to add theatre..!")
    else:
        city_name = user_input("Select theatre number:", TMS)
        try:
            th_name = user_input("Select theatre number:", TMS[city_name])
        except (KeyError, ValueError):
            print("Invalid inout..!")
            rename_theatre()
            return
        if not TMS[city_name]:
            print("Theatre is already exist..!")
        else:
            if th_name in TMS[city_name]:
                new_th_name = input("Enter new theatre name :").upper()
                TMS[city_name][new_th_name] = TMS[city_name][th_name]
                del TMS[city_name][th_name]


def delete_theatre():
    if not TMS:
        print("City not found to add theatre..!")
    else:
        try:
            city_name = user_input("Enter city number :", TMS)
        except (KeyError, ValueError):
            print(colored("Invalid Input...!", 'red'))
            delete_theatre()
            return
        if not TMS[city_name]:
            print("No Theatre Found..!")
        else:
            try:
                th_name = user_input("Select theatre number:", TMS[city_name])
            except (KeyError, ValueError):
                print(colored("Invalid Input...!", 'red'))
                delete_theatre()
                return
            if th_name in TMS[city_name]:
                del TMS[city_name][th_name]


def list_theatre():
    if not TMS:
        print("City not found to add theatre..!")
    else:
        cities = list_cities()
        try:
            city_num = int(input("Select city number :"))
        except:
            print("Only Numeric value allowed..!")
            list_theatre()
            return
        theatres = {}
        if city_num in cities:
            city_name = cities[city_num]
            th_loop = 1
            if not TMS[city_name]:
                print("No Theatre Found..!")
                return
            else:
                for key in TMS[city_name]:
                    print(th_loop, key)
                    theatres[th_loop] = key
                    th_loop = th_loop + 1
            return theatres
        else:
            print("City number not matched..!")


def add_movies():
    if not TMS:
        print("No city found to add movies..!")
    else:
        try:
            city_name = user_input("Enter city :", TMS)
        except (KeyError, ValueError):
            print(colored("Invalid Input...!", 'red'))
            add_movies()
            return
        if not TMS[city_name]:
            print("No theatre found to add movies...!")
        else:
            try:
                th_name = user_input("Enter theatre :", TMS[city_name])
            except (KeyError, ValueError):
                print(colored("Invalid Input...!", 'red'))
                add_movies()
                return
            mov_name = input("Enter movie name :").upper()
            if mov_name in TMS[city_name][th_name]:
                print("This movie is already exist..!")
                return
            else:
                TMS[city_name][th_name][mov_name] = {}


def list_movies():
    if not TMS:
        print("No city found to add movies..!")
    else:
        city_name = user_input("Select city number:", TMS)
        if not TMS[city_name]:
            print("No theatre found..!")
        else:
            th_name = user_input("Select theatre number:", TMS[city_name])
            print_list(TMS[city_name][th_name])


def rename_movies():
    if not TMS:
        print("No city found to add movies..!")
    else:
        try:
            city_name = user_input("Select city number:", TMS)
        except (KeyError, ValueError):
            print("Invalid inout...!")
            rename_movies()
            return
        if not TMS[city_name]:
            print("No Theatre found to rename movies...!")
        else:
            try:
                th_name = user_input("Select theatre number:", TMS[city_name])
            except (KeyError, ValueError):
                print("Invalid inout...!")
                rename_movies()
                return
            try:
                mov_name = user_input("select movie number :",
                                      TMS[city_name][th_name])
            except (KeyError, ValueError):
                print("Invalid inout..!")
                rename_movies()
                return
            print(mov_name)
            if mov_name in TMS[city_name][th_name]:
                new_mov_name = input("Enter new movie name :").upper()
                if new_mov_name in TMS[city_name][th_name]:
                    print("This movie is already exist...!")
                else:
                    TMS[city_name][th_name][new_mov_name] = TMS[city_name][th_name][mov_name]
                    del TMS[city_name][th_name][mov_name]


def delete_movies():
    if not TMS:
        print("First add city...!")
    else:
        try:
            city_name = user_input("Select city number:", TMS)
        except (KeyError, ValueError):
            print("Invalid inout...!")
            delete_movies()
            return
        if not TMS[city_name]:
            print("No theatre found..!")
        else:
            try:
                th_name = user_input("Select theatre number:", TMS[city_name])
            except (KeyError, ValueError):
                print("Invalid inout...!")
                delete_movies()
                return
            if not TMS[city_name][th_name]:
                print("No Movies Found...!")
            else:
                try:
                    mov_name = user_input("select movie number :",
                                          TMS[city_name][th_name])
                except (KeyError, ValueError):
                    print(colored("Invalid Input...!", 'red'))
                    delete_movies()
                    return
                print(mov_name)
                if mov_name in TMS[city_name][th_name]:
                    del TMS[city_name][th_name][mov_name]
                else:
                    print("Wrong movie selected delete again..!")


def add_show():
    if not TMS:
        print(" No city Found to add show add new citites first..!")
    else:
        try:
            city_name = user_input("Select City Number :", TMS)
        except (KeyError, ValueError):
            print(colored("Invalid Input...!", 'red'))
            add_show()
            return
        if not TMS[city_name]:
            print("No theatre found..!@")
        else:
            try:
                th_name = user_input("Select Theatre Number :", TMS[city_name])
            except (KeyError, ValueError):
                print(colored("Invalid Input...!", 'red'))
                add_show()
                return
            if not TMS[city_name][th_name]:
                print("No Movies found..!")
            else:
                try:
                    mov_name = user_input("Select Movie Number :",
                                          TMS[city_name][th_name])
                except (KeyError, ValueError):
                    print(colored("Invalid Input...!", 'red'))
                    add_show()
                    return
                if mov_name in TMS[city_name][th_name]:
                    print()
                    print(colored('Add date in this formate DD/MM/YYYY ', 'red'))
                    print()
                    temp_date = input("Enter show date :")
                    TMS[city_name][th_name][mov_name][temp_date] = {}
                    try:
                        seat_fees = int(input("Enter fee of one seat :"))
                    except:
                        print("Only Numeric value allowd add show again..!")
                        add_show()
                        return
                    TMS[city_name][th_name][mov_name][temp_date][seat_fees] = {}
                    try:
                        seat_size = int(input("Add Total Seats :"))
                    except:
                        print("Only Numeric value allowd add show again..!")
                        add_show()
                        return
                    for iloop in range(1, seat_size+1):
                        TMS[city_name][th_name][mov_name][temp_date][seat_fees][iloop] = [
                            "Avilable"]


def book_ticket():
    if not TMS:
        print("No city found..!")
    else:
        try:
            city_name = user_input("Enter city number :", TMS)
        except (KeyError, ValueError):
            print(colored("Invalid Input...!", 'red'))
            book_ticket()
            return

        if not TMS[city_name]:
            print("No Theatre found...!")
        else:
            try:
                th_name = user_input("Select theatre number :", TMS[city_name])
            except (KeyError, ValueError):
                print(colored("Invalid Input...!", 'red'))
                book_ticket()
                return
            if not TMS[city_name][th_name]:
                print("no movies found..!")
            else:
                try:
                    mov_name = user_input("Select movie number :",
                                          TMS[city_name][th_name])
                except(ValueError, KeyError):
                    print(colored("Invalid Input...!", 'red'))
                    book_ticket()
                    return
                if not TMS[city_name][th_name][mov_name]:
                    print("No dates found for this show..!")
                else:
                    try:
                        mov_date = user_input("select date number :",
                                              TMS[city_name][th_name][mov_name])
                    except (ValueError, KeyError):
                        print(colored("Invalid Input...!", 'red'))
                        book_ticket()
                        return
                    if not TMS[city_name][th_name][mov_name][mov_date]:
                        print("Theare is not seat found for this show..!")
                    else:
                        try:
                            seat_fees = user_input("Press 1 To continue for ticket booking :",
                                                   TMS[city_name][th_name][mov_name][mov_date])
                        except(ValueError, KeyError):
                            print(colored("Invalid Input...!", 'red'))
                            book_ticket()
                            return
                        try:
                            select_seat = user_book_seat(
                                "Select seat for book :", TMS[city_name][th_name][mov_name][mov_date][seat_fees])
                        except (ValueError, KeyError):
                            print(colored("Invalid Input...!", 'red'))
                            book_ticket()
                            return

                        while True:
                            if select_seat in TMS[city_name][th_name][mov_name][mov_date][seat_fees]:
                                if TMS[city_name][th_name][mov_name][mov_date][seat_fees][select_seat] == ["Avilable"]:
                                    TMS[city_name][th_name][mov_name][mov_date][seat_fees][select_seat] = [
                                        "Booked"]
                                    print("Seat is Booked")
                                    return
                                else:
                                    print("Seat is already booked..!")
                                    return


def handler(signum, frame):
    write_data()
    print()
    exit(1)


signal.signal(signal.SIGTSTP, handler)
signal.signal(signal.SIGINT, handler)


def print_list(dict):
    dict_loop = 1
    for x in dict:
        print(dict_loop, x)
        dict_loop = dict_loop + 1


def seat_input(msg, dict):
    dict_loop = 1
    temp_dict = {}

    for x in dict:
        print("Book seat No:", x)
        temp_dict[dict_loop] = x
        dict_loop = dict_loop + 1
    choice = int(input(msg))
    return temp_dict[choice]


def cancel_booked_seat():
    if not TMS:
        print("There is no city ..!")
    else:
        try:
            city_name = user_input("Enter city number :", TMS)
        except (KeyError, ValueError):
            print(colored("Invalid Input...!", 'red'))
            cancel_booked_seat()
            return
        if not TMS[city_name]:
            print("There is not theatre found..!")
        else:
            try:
                th_name = user_input("Select theatre number :", TMS[city_name])
            except (ValueError, KeyError):
                print(colored("Invalid Input...!", 'red'))
                cancel_booked_seat()
                return
            if not TMS[city_name][th_name]:
                print("No movies found for cancellation..!")

            else:
                try:
                    mov_name = user_input("Select movie number :",
                                          TMS[city_name][th_name])
                except (ValueError, KeyError):
                    print(colored("Invalid Input...!", 'red'))
                    cancel_booked_seat()
                    return
                if not TMS[city_name][th_name][mov_name]:
                    print("There is no date found..!")
                else:
                    try:
                        mov_date = user_input("select date number :",
                                              TMS[city_name][th_name][mov_name])
                    except (ValueError, KeyError):
                        print(colored("Invalid Input...!", 'red'))
                        cancel_booked_seat()
                        return
                    if not TMS[city_name][th_name][mov_name][mov_date]:
                        print("There is no seat for cancellation...!")
                    else:
                        try:
                            seat_fees = user_input("Press 1 To continue for ticket booking :",
                                                   TMS[city_name][th_name][mov_name][mov_date])
                        except (ValueError, KeyError):
                            print(colored("Invalid Input...!", 'red'))
                            cancel_booked_seat()
                            return
                        try:
                            select_seat = user_cancel_seat(
                                "Select seat for book :", TMS[city_name][th_name][mov_name][mov_date][seat_fees])
                        except (KeyError, ValueError):
                            print(colored("Invalid Input...!", 'red'))
                            cancel_booked_seat()
                            return
                        while True:
                            if select_seat in TMS[city_name][th_name][mov_name][mov_date][seat_fees]:
                                if TMS[city_name][th_name][mov_name][mov_date][seat_fees][select_seat] == ["Booked"]:
                                    TMS[city_name][th_name][mov_name][mov_date][seat_fees][select_seat] = [
                                        "Avilable"]
                                    print("Seat has been cancelled..!")
                                    return
                                else:
                                    print("Wrong selected seat..!")
                                    return


def user_book_seat(msg, dict):
    dict_loop = 1
    temp_dict = {}

    for x in dict:
        if dict[x] == ["Avilable"]:
            print(f"press {dict_loop} to book seat No:{x}")
            temp_dict[dict_loop] = x
            dict_loop = dict_loop + 1
    choice = int(input(msg))
    return temp_dict[choice]


def user_cancel_seat(msg, dict):
    dict_loop = 1
    temp_dict = {}

    for x in dict:
        if dict[x] == ["Booked"]:
            print(f"press {dict_loop} to cancel booked seat No:{x}")
            temp_dict[dict_loop] = x
            dict_loop = dict_loop + 1
    choice = int(input(msg))
    return temp_dict[choice]
