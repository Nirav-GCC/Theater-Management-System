from tms_admin import book_ticket, cancel_booked_seat, list_cities, list_movies, list_theatre, write_data


def tms_user():

    while True:
        user_choice = int(input(
            "\n 0.Exit\n 1.List City\n 2.List Theatre\n 3.List Movies\n 4.Book Ticket\n 5.Cancel Ticket\n *Select Option :"))
        if user_choice == 0:
            write_data()
            return
        elif user_choice == 1:
            list_cities()
        elif user_choice == 2:
            list_theatre()
        elif user_choice == 3:
            list_movies()
        elif user_choice == 4:
            book_ticket()
        elif user_choice == 5:
            cancel_booked_seat()
        else:
            print("Wrong choice...!")
