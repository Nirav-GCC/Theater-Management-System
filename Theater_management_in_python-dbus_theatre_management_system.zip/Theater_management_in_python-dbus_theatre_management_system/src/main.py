from tms_admin import tms_admin, write_data, load_data
import os.path

from tms_user import tms_user


if os.path.exists('TMS_DATA.json'):
    load_data()
else:
    write_data()


while True:
    try:
        user_management = int(
            input("\n 0.Exit\n 1.Admin\n 2.User\n *Select the option :"))
    except:
        print("Only Numeric Values allowed...!")
        exit(1)
    if user_management == 0:
        exit(1)
    elif user_management == 1:
        tms_admin()
    elif user_management == 2:
        tms_user()
    else:
        print("Wrong choice..!")
