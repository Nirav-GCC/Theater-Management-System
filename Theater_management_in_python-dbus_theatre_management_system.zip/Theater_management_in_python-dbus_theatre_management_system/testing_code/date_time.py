from datetime import datetime
cr_date = datetime(2013, 10, 31, 18, 23, 29)
cr_date.strftime('%m/%d/%Y')
print(cr_date)