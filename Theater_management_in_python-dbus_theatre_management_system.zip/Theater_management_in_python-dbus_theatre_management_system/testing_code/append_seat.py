dict = {}
n = int(input())
n = n+1
def add_seat():
  
    dict["seats"] = {}
    for i in range(1,n):
        
        dict["seats"][i] = ["not booked"]
    
    print(dict)

def book_seat():
    seat_number = int(input("Enter the seat number to book :"))
    for i in range(1,n):
        if dict["seats"][i] == dict["seats"][seat_number]:
            dict["seats"][i] = ["booked"]
            print(dict)
            return
        else:
            print("Wrong seat number") 
while True:
    add_seat()
    book_seat()
